package com.example.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetUserRequest {
	
	private Long candidateId;
	
	private String ipAdd;

}
