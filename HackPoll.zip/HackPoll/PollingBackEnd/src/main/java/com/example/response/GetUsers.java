package com.example.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetUsers {
	
	private Long userId;
	private String userName;

}
