import { Expert } from "./expert"

export class Candidate{
    candidateId:number
	candidateName:string
    challangesSolved:number
    noOfVotes:number
    candidateExperienceLevel:number
    expertIn:Expert
}