import { Candidate } from "./candidate";

export class GetCandidateResponse{
    candidate:Candidate
	voted:boolean
}