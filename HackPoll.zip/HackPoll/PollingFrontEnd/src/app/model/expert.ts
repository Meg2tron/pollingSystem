export class Expert{
    expertId:number
	ds:number
	algo:number
	java:number
	python:number
	angular:number
}