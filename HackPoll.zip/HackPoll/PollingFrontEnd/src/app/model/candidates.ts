export class Candidates{
    userId : number;
    userName : string;
}