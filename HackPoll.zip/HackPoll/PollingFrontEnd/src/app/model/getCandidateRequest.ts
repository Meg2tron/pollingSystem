export class GetCandidateRequest{
    candidateId:number
    ipAdd:String
}