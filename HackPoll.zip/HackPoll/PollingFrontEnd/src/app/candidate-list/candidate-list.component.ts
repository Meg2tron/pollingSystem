import { Component, OnInit } from '@angular/core';
import { CandidateService } from '../service/candidate.service';
import { Candidates } from '../model/candidates';
import { GetCandidateRequest } from '../model/getCandidateRequest';
import { GetCandidateResponse } from '../model/getCandidateResponse';
import { Candidate } from '../model/candidate';
import { Expert } from '../model/expert';
import { Router } from '@angular/router';
import { ModalService } from '../_modal';
declare var swal:any;
@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.css']
})
export class CandidateListComponent implements OnInit {


  candidates: Candidates[];
  candidateRequest = new GetCandidateRequest()
  candidateResponse = new GetCandidateResponse()
  candidate = new Candidate()
  expert = new Expert()
  ipAdd : string

  constructor(private candidateService: CandidateService, private modalService: ModalService,private router : Router) {
    
  }
  

  ngOnInit(): void {
    
    this.getAllCandidates()
    this.candidateService.getIpAddress().subscribe((res:any)=>{
      this.ipAdd = res.ip
})
  }

  getAllCandidates()
  {
    this.candidateService.getCandidateList().subscribe(
      resp=>{
        this.candidates = resp  
      }
    )
  }

  showCandidateDetails(candidateId)
  {
    this.candidateRequest.candidateId = candidateId
    this.candidateRequest.ipAdd = this.ipAdd
    this.candidateService.getCandidate(this.candidateRequest).subscribe(
      resp=>{
        this.candidateResponse = resp
        this.candidate = this.candidateResponse.candidate
        this.expert = this.candidate.expertIn
      }
    )
  }
  

  vote(candidateId: number) {

    swal({
      title: "Are you sure?",
      text: "You want to Vote ?",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willInvite) => {
      if (willInvite) {
        this.saveVote(candidateId);
      } else {
        swal("CANCELLED","You cancelled the vote","error");
      }
    });

    
  }

  saveVote(candidateId: number)
  {
    this.candidateRequest.candidateId = candidateId
    this.candidateRequest.ipAdd = this.ipAdd
    this.candidateService.saveVote(this.candidateRequest).subscribe(
      resp=>{
        console.log(resp)
      }
    )
  }

  openModal(id: string) {
    this.modalService.open(id);
  }

closeModal(id: string) {
    this.modalService.close(id);
  }

}
