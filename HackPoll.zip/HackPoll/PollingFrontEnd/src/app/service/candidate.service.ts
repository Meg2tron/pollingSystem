import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Candidates } from '../model/candidates';
import { GetCandidateRequest } from '../model/getCandidateRequest';
// import { environment } from '../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  // baseUrl = 'http://localhost:8080/poll/'
baseUrl = 'https://lrning.herokuapp.com/poll/'
  constructor(private http : HttpClient) { }

  getCandidateList():Observable<any>
  {
    
    return this.http.get(`${this.baseUrl}`);
  }

  getIpAddress()
  {
    return this.http.get('http://api.ipify.org?format=json')
  }

  getCandidate(candidateRequest : GetCandidateRequest):Observable<any>
  {
    return this.http.post(`${this.baseUrl}`+candidateRequest.candidateId+'/',candidateRequest)
  }

  saveVote(candidateRequest : GetCandidateRequest):Observable<any>
  {
    console.log(JSON.stringify(candidateRequest))
    return this.http.post(`${this.baseUrl}`,candidateRequest)
  }
}
